# -*- coding: utf-8 -*-
"""
Created on Thu Jun 25 21:59:43 2020

@author: Anubhav
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Sep 20 12:50:26 2019

@author: Aditya Sharma
"""
import time
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from pprint import pprint
#from time import sleep
import mpu6050
import requests

def send_msg():
    text="Health Emergency of the Patient"    
    url = "https://www.fast2sms.com/dev/bulk"
    payload = "sender_id=FSTSMS&message="+text+"&language=english&route=p&numbers=8076669489,9811613731"
    headers = {
            'authorization': "FHQfIyEYPau6qeUlTS0K7Gtz9RMxWoDg1ZCLBbwkhcX258sdni0VEe3fSuQkN4XwUApDvsnjIi91LdTO",
            'Content-Type': "application/x-www-form-urlencoded",
            'Cache-Control': "no-cache",
            }
 
    response = requests.request("POST", url, data=payload, headers=headers)
 
    print(response.text)


scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']

creds = ServiceAccountCredentials.from_json_keyfile_name("interns.json", scope)

client = gspread.authorize(creds)

sheet = client.open("sensors data").sheet1  

data = sheet.get_all_records()  

pprint(data)

insertRow = []
sheet.insert_row(insertRow, 2)


 