# import many libraries
from __future__ import print_function  
from googleapiclient.discovery import build  
from httplib2 import Http  
from oauth2client import file, client, tools  
from oauth2client.service_account import ServiceAccountCredentials  

import datetime

import matplotlib.pyplot as plt              
import matplotlib.animation as animation
import xlrd

# My Spreadsheet ID ... See google documentation on how to derive this
MY_SPREADSHEET_ID = 'name.....'                                                                           


def update_sheet(heart_rate, blood_oxgyen):  
    """update_sheet method:
       appends a row of a sheet in the spreadsheet with the 
       the latest hreat rate and blood oxgyen
    """
    # authentication, authorization step
    SCOPES = 'https://www.googleapis.com/auth/spreadsheets'
    creds = ServiceAccountCredentials.from_json_keyfile_name( 
            'bme280-project.json', SCOPES)
    service = build('sheets', 'v4', http=creds.authorize(Http()))

    # Call the Sheets API, append the next row of sensor data
    # values is the array of rows we are updating, its a single row
    
	
	values = [ [ str(datetime.datetime.now()), 'heart_rate', max.red, 'blood_oxgyen', mx30.ir, 'Humidity', humidity ] ]
    body = { 'values': values }
    # call the append API to perform the operation
    result = service.spreadsheets().values().append(
                spreadsheetId=MY_SPREADSHEET_ID, 
                range=sheetname + '!A1:G1',
                valueInputOption='USER_ENTERED', 
                insertDataOption='INSERT_ROWS',
                body=body).execute()                     


def main():  
    """main method:
       reads the BME280 chip to read the three sensors, then
       call update_sheets method to add that sensor data to the spreadsheet
    """
	        mx30.set_mode(max30100.MODE_HR)
            mx30.read_sensor()
            print("HRate sensor .ir: {} and SpO2 .red: {}".format(mx30.ir, mx30.red))
    
            update_sheet("Haifa_outside", tempC, pressure, humidity)


if __name__ == '__main__':  
    main()



hsif = pd.read_excel('path','Sheet2', skiprows=3)
data = hsif.columns.values[3]
print(data)
fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)
xs = []
ys = []


# This function is called periodically from FuncAnimation
def animate(i, xs, ys):

    # Read data from sensor
    grap_date=open("fie name"),read

    # Add x and y to lists
    xs.append(dt.datetime.now().strftime('%H:%M '))
    ys.append(temp_c) 

    # Limit x and y lists to 20 items
    xs = xs[-20:]
    ys = ys[-20:]

    # Draw x and y lists
    ax.clear()
    ax.plot(xs, ys)

plt.rcParams["figure.figsize"] = (15,4)
plt.title('blood_oxgyen')
plt.xlabel('Time(s)')
plt.ylabel('blood_oxgyen')
aX=grap_date['blood_oxgyen']
plt.plot(aX, label = "Humidity", color='blue')
plt.legend()


plt.rcParams["figure.figsize"] = (15,4)
plt.title('Hate_rate')
plt.xlabel('Time(s)')
plt.ylabel('Hate_rate')
aX=grap_datedata['Humidity']
plt.plot(aX, label = "Hate_rate", color='red')
plt.legend()


# Set up plot to call animate() function periodically
ani = animation.FuncAnimation(fig, animate, fargs=(xs, ys), interval=1000)
plt.show()