# -*- coding: utf-8 -*-
"""
Created on Thu Jun 25 20:36:54 2020

@author: Anubhav
"""

import speech_recognition as sr
import datetime
import warnings
import calendar
import random
import wikipedia
import numpy as np
import pandas as pd
import pyttsx3
import re
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from mpu6050 import mpu6050 		#Importing mph module and time function and GPIO modules
import time
import RPi.GPIO as GPIO
import pyaudio
import requests
import max30102
import RPi.GPIO as GPIO
import hrcalc
import os
import spidev
import glob
import time
import sys
import datetime
import gspread
import os
import sys
from luma.core.interface.serial import i2c
from luma.core.render import canvas
from luma.oled.device import ssd1306, ssd1325, ssd1331, sh1106

warnings.filterwarnings('ignore')

def listToString(s):   
    str1 = ""  
    for ele in s:  
        str1 += ele      
    return str1 

def find_the_word(text):

    #text = "move to the left side"
    ps = PorterStemmer()
    clean_review = []
    text = re.sub('[^a-zA-Z]', ' ', text)
    text = text.lower()
    text = text.split()    
    text = [ps.stem(word) for word in text if not word in set(stopwords.words('english'))]
    text = ' '.join(text)
    clean_review.append(text)
    find=listToString(clean_review)  

    searchObj = re.search( r'left', find, re.M|re.I)
    searchObjJ = re.search( r'right', find, re.M|re.I)
    searchObjK = re.search( r'forward', find, re.M|re.I)
    searchObjL = re.search( r'backward', find, re.M|re.I)
    
    if searchObj:
        return searchObj.group()
    elif searchObjJ:
        print ("found: ", searchObjJ.group())
        return searchObjJ.group()
    elif searchObjK:
        print ("found: ", searchObjK.group())
        return searchObjK.group()
    elif searchObjL:
        print ("found: ", searchObjL.group())
        return searchObjL.group()
    else:
        print ("Nothing found!!")    
        return "Nothing found!!"
    
def send_msg():
    text="Health Emergency of the Patient"    
    url = "https://www.fast2sms.com/dev/bulk"
    payload = "sender_id=FSTSMS&message="+text+"&language=english&route=p&numbers=8076669489,9811613731"
    headers = {
            'authorization': "FHQfIyEYPau6qeUlTS0K7Gtz9RMxWoDg1ZCLBbwkhcX258sdni0VEe3fSuQkN4XwUApDvsnjIi91LdTO",
            'Content-Type': "application/x-www-form-urlencoded",
            'Cache-Control': "no-cache",
            }
 
    response = requests.request("POST", url, data=payload, headers=headers)
 
    print(response.text)


def news():
    url = ('http://newsapi.org/v2/top-headlines?'
       'country=in&'
       'apiKey=90789a8d27904241b3f39b13f9ae595f')
    response = requests.get(url)
    print(response.json())
    return response.json()    
        
def main(text):
       audio1 = recordAudio()
       text = audio1
       text = {}
       word=find_the_word(text)

       if 'stop' in word:
           D0=GPIO.output(6, GPIO.LOW)	
           D1=GPIO.output(13, GPIO.LOW)
           D2=GPIO.output(19, GPIO.LOW)
           D3=GPIO.output(26, GPIO.LOW)
           assistantResponse("Okay master,wheel get stop")
         #  call(["espeak", "-s140  -ven+18 -z" ," Okay master,wheel get stop"])
           print("stop")
        

       elif 'forward' in word:
          D0=GPIO.output(6, GPIO.HIGH)
          D1=GPIO.output(13, GPIO.LOW)	#From the configuration table you can match the values for each motion
          D2=GPIO.output(19, GPIO.HIGH)
          D3=GPIO.output(26, GPIO.LOW)
          print('FORWARD')
          assistantResponse("Okay master,moving forward")
          time.sleep(0.5)


       elif 'backword' in word:
           D0=GPIO.output(6, GPIO.LOW)
           D1=GPIO.output(13, GPIO.HIGH)
           D2=GPIO.output(19, GPIO.LOW)
           D3=GPIO.output(26, GPIO.HIGH)
           print('BACKWARD')
           assistantResponse("Okay master,coming backward")

           time.sleep(0.5)
    #RIGHT
       elif 'right' in word:
           D0=GPIO.output(6, GPIO.LOW)
           D1=GPIO.output(13, GPIO.HIGH)
           D2=GPIO.output(19, GPIO.LOW)
           D3=GPIO.output(26, GPIO.LOW)
           print('RIGHT')
           assistantResponse("Okay master")


  #left
       elif 'left ' in word:
          D0=GPIO.output(6, GPIO.LOW)
          D1=GPIO.output(13, GPIO.LOW)
          D2=GPIO.output(19, GPIO.LOW)
          D3=GPIO.output(26, GPIO.HIGH)
          print('LEFT')
          assistantResponse("Okay master")

          time.sleep(.5)
          text()
          time.sleep(1)
          

def recordAudio():
    r = sr.Recognizer()
    print("Please talk")
    
    with sr.Microphone() as source:
    # read the audio data from the default microphone
        audio_data = r.record(source, duration=10)
        print("Recognizing...")
    # convert speech to text
        text = r.recognize_google(audio_data)
        print(text)    
        return text
    

def assistantResponse(text):
    print(text)
    
    
    engine = pyttsx3.init()

    engine.setProperty('rate',125)
    engine.say(text)
    engine.runAndWait()

    
def execute_bot():
    res="Please reply with yes/Yes or no/No for the following symptoms"
    assistantResponse(res)
    print("Please reply with yes/Yes or no/No for the following symptoms") 
    def print_disease(node):
        print(node)
        node = node[0]
        print(len(node))
        val  = node.nonzero() 
       
        disease = labelencoder.inverse_transform(val[0])
        return disease
    def tree_to_code(tree, feature_names):
        tree_ = tree.tree_
        
        feature_name = [
            feature_names[i] if i != _tree.TREE_UNDEFINED else "undefined!"
            for i in tree_.feature
        ]
        
        symptoms_present = []
        def recurse(node, depth):
            indent = "  " * depth
            if tree_.feature[node] != _tree.TREE_UNDEFINED:
                name = feature_name[node]
                threshold = tree_.threshold[node]
                res= name + " ?"
                assistantResponse(res)
                
                print(name + " ?")
                text = recordAudio()
                ans = input()
                ans = ans.lower()
                
                
                if text == 'yes':
                    val = 1
                else:
                    val = 0
                if  val <= threshold:
                    recurse(tree_.children_left[node], depth + 1)
                else:
                    symptoms_present.append(name)
                    recurse(tree_.children_right[node], depth + 1)
            else:
                present_disease = print_disease(tree_.value[node])
                res1="You may have " +  present_disease
                assistantResponse(res1)
                print( "You may have " +  present_disease )
                print()
                red_cols = dimensionality_reduction.columns 
                symptoms_given = red_cols[dimensionality_reduction.loc[present_disease].values[0].nonzero()]
                res2="symptoms present  " + str(list(symptoms_present))
                assistantResponse(res2)
                print("symptoms present  " + str(list(symptoms_present)))
                print()
                res3="symptoms given "  +  str(list(symptoms_given))
                assistantResponse(res3)
                print("symptoms given "  +  str(list(symptoms_given)) )  
                print()
                confidence_level = (1.0*len(symptoms_present))/len(symptoms_given)
                res4="confidence level is " + str(confidence_level)
                assistantResponse(res4)
                print("confidence level is " + str(confidence_level))
                print()
                res5='The model suggests:'
                assistantResponse(res5)
                print('The model suggests:')
                print()
                row = doctors[doctors['disease'] == present_disease[0]]
                res5='Consult ', str(row['name'].values)
                assistantResponse(res5)
                print('Consult ', str(row['name'].values))
                print()
                res5='Visit ', str(row['link'].values)
                assistantResponse(res5)
                print('Visit ', str(row['link'].values))
                
                
    
        recurse(0, 1)
    
    tree_to_code(classifier,cols)    

def wakeWord(text):
    WAKE_WORDS = ['hey computer', 'okay computer']

    text = text.lower()
    for phrase in WAKE_WORDS:
        if phrase in text:
            return True
    return False


def getDate():
    
    now = datetime.datetime.now()
    my_date = datetime.datetime.today()
    weekday = calendar.day_name[my_date.weekday()]
    monthNum = now.month
    dayNum = now.day
    
    month_names = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
    
    ordialNumbers = ['1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th', '9th', '10th', '11th', '12th', '13th', '14th', '15th', '16th', '17th', '18th', '19th', '20th', '21st', '22nd', '23rd', '24th', '25th', '26th', '27th', '28th', '29th', '30th', '31st']
    
    return 'Today is '+weekday+' '+ month_names[monthNum - 1]+' the '+ ordialNumbers[dayNum - 1]+'. '

def greeting(text):
    
    GREETING_INPUTS = ['hi', 'hey', 'hola', 'greetings', 'wassup', 'hello']
    GREETING_RESPONSES = ['howdy', 'whats good', 'hello', 'hey there']    
    
    for word in text.split():
        if word.lower() in GREETING_INPUTS:
            return random.choice(GREETING_RESPONSES) +'.'
    
    
    return ''

def getPerson(text):
    
    wordList = text.split()

    for i in range(0, len(wordList)):
        if i + 3 <= len(wordList) - 1 and wordList[i].lower() == 'who' and wordList[i+1].lower() =='is':
            return wordList[i+2] + ' '+ wordList[i+3]
        
while True:
    
    text = recordAudio()
    response = ''
    
    if(wakeWord(text) == True):
        
        response = response + greeting(text)
        
        if('date' in text):
            get_date = getDate()
            response = response + ' '+get_date

        if('time'in text):
            now = datetime.datetime.now()
            meridiem =''
            if now.hour >=12:
                meridiem = 'p.m'
                hour = now.hour - 12
            else:
                meridiem  = 'a.m'
                hour = now.hour
                
            if now.minute < 10:
                minute = '0'+str(now.minute)
            else:
                minute = str(now.minute)
                
            response = response +' '+'It is '+str(hour)+ ':'+ minute+ ' '+meridiem + ' .'
            
        
        if('who is' in text):
            person = getPerson(text)
            wiki = wikipedia.summary(person, sentences=2)
            response = response +' '+ wiki
        
        
            assistantResponse(response)
            
            
        if('health care' in text):    
            training_dataset = pd.read_csv('Training.csv')
            training_dataset.columns = training_dataset.columns.str.replace('_', ' ')
            test_dataset = pd.read_csv('Testing.csv')
            test_dataset.columns = test_dataset.columns.str.replace('_', ' ')

            # Slicing and Dicing the dataset to separate features from predictions
            X = training_dataset.iloc[:, 0:132].values
            y = training_dataset.iloc[:, -1].values

            # Dimensionality Reduction for removing redundancies
            dimensionality_reduction = training_dataset.groupby(training_dataset['prognosis']).max()

            # Encoding String values to integer constants
            from sklearn.preprocessing import LabelEncoder
            labelencoder = LabelEncoder()
            y = labelencoder.fit_transform(y)

            # Splitting the dataset into training set and test set
            from sklearn.model_selection import train_test_split
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 0)

            # Implementing the Decision Tree Classifier
            from sklearn.tree import DecisionTreeClassifier
            classifier = DecisionTreeClassifier()
            classifier.fit(X_train, y_train)

            # Saving the information of columns
            cols     = training_dataset.columns
            cols     = cols[:-1]


            # Checking the Important features
            importances = classifier.feature_importances_
            indices = np.argsort(importances)[::-1]
            features = cols

            # Implementing the Visual Tree
            from sklearn.tree import _tree

            # Method to simulate the working of a Chatbot by extracting and formulating questions



            # This section of code to be run after scraping the data

            doc_dataset = pd.read_csv('doctors_dataset.csv', names = ['Name', 'Description'])


            diseases = dimensionality_reduction.index
            diseases = pd.DataFrame(diseases)

            doctors = pd.DataFrame()
            doctors['name'] = np.nan
            doctors['link'] = np.nan
            doctors['disease'] = np.nan
            
            doctors['disease'] = diseases['prognosis']


            doctors['name'] = doc_dataset['Name']
            doctors['link'] = doc_dataset['Description']

            record = doctors[doctors['disease'] == 'AIDS']
            record['name']
            record['link']
            
            # Execute the bot and see it in Actionn
            execute_bot()
            

        if('start' in text):
            audio1 = recordAudio()
            text = audio1
            text = {}
            word=find_the_word(text)
            assistantResponse(" Okay master, waiting for you text")
            main(word)
            
        if('news' in text):
            news()
            speak= news()
            assistantResponse(speak)
            



GPIO.setup(7, GPIO.OUT)
GPIO.setup(26, GPIO.OUT)
max30102=0x57	
address=0x3C       #oled display

# Enter your account details (Your Gmail ID and Password) as shown here
email = 'gajjar.rushi@gmail.com'
password = 'raspberrypi'

#Name of Spreadsheet created in Google Drive
spreadsheet = ('Logging')

#Putting the exception call in python to attempt for logging in Gmail
try:
     ret = gspread.login(email,password)
except:
     print('Oops! Check Internet Connection or Login Credentials')
     sys.exit()

#open the spreadsheet by either of these two options
worksheet = ret.open(spreadsheet).sheet1
#or with the spreadsheet key
#worksheet = ret.open_by_key('1eQth-TY4FXFKChB5RFPhelQ6zn47NWDESh13WkXGQAk')
#prefer First Option


red, ir = m.read_sequential() # get LEDs readings

ir = []
with open("ir.log", "r") as f:
      for line in f:
          ir.append(int(line))
		
red = []
with open("red.log", "r") as f:
    for line in f:
	      red.append(int(line))
for i in range(100):
        print(hrcalc.calc_hr_and_spo2(ir[25*i:25*i+100], red[25*i:25*i+100]))
        t_socket.connect(("192.168.52.1", 80))
        test_socket.sendto(hrcalc.calc_hr_and_spo2(ir[25*i:25*i+100], red[25*i:25*i+100]),(UDP_IP, UDP_PORT))  # send the data to google sheet 
        
if ir[25*i:25*i+100]<=70 or ir[25*i:25*i+100]>100:
    send_msg()
elif red[25*i:25*i+100]<=100 or red[25*i:25*i+100]<=60:
    send_msg()
         
device = ssd1306(serial, rotate=0)
with canvas(device) as draw:
    
    draw.rectangle(device.bounding_box, outline="white", fill="black")
    
    
while 1:
    time.sleep(1)

        # mx30.shutdown()


if __name__ == "__main__":
  main()




   
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            